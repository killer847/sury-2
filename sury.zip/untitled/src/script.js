const yesButton = document.getElementById("yesButton");
const noButton = document.getElementById("noButton");
const pregunta = document.getElementById("pregunta");
const respuesta = document.getElementById("respuesta");

// Efecto botón NO
noButton.addEventListener("mouseover", agrandarSi);
noButton.addEventListener("touchstart", agrandarSi);

// Efecto botón SÍ
yesButton.addEventListener("click", mostrarRespuesta);

function agrandarSi() {
  let fontSize = parseInt(window.getComputedStyle(yesButton).fontSize);
  yesButton.style.fontSize = fontSize + 10 + "px";

  // Vibración (solo móviles)
  if (navigator.vibrate) navigator.vibrate(50);
}

function mostrarRespuesta() {
  pregunta.classList.add("hidden");
  respuesta.classList.remove("hidden");
}
